import pygame
import os
from button import Button

pygame.init()
pygame.font.init()
pygame.mixer.init()

# Window display
WIDTH, HEIGHT = 1200, 800
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("𐌂𐌀𐌕𐌕𐌀𐌂𐌋𐌄 ᓚᘏᗢ")

# Colours of game
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PURPLE = (110, 33, 126)
BLUE = (0, 240, 255)

LINE = pygame.Rect(0, HEIGHT//2 - 1, WIDTH, 2)

# Load Sounds
BULLET_HIT_SOUND = pygame.mixer.Sound('Assets/cat_meow.wav')
BULLET_FIRE_SOUND = pygame.mixer.Sound('Assets/pew.mp3')
VICTORY_SOUND = pygame.mixer.Sound('Assets/gong.mp3')

# Load Fonts
HEALTH_FONT = pygame.font.SysFont('Lucida Console', 40)
WINNER_FONT = pygame.font.SysFont('Lucida Console', 100)
BUTTON_FONT = pygame.font.SysFont('Lucida Console', 1)

FPS = 60
VEL = 5
BULLET_VEL = 7
MAX_BULLETS = 5
SPACESHIP_WIDTH, SPACESHIP_HEIGHT = 55, 40

BLUE_HIT = pygame.USEREVENT + 1
PURPLE_HIT = pygame.USEREVENT + 2

# Load Images
blue_cat = pygame.image.load(os.path.join("Assets/blucat.png"))
pruple_cat = pygame.image.load(os.path.join("Assets/purcat.png"))
BACKGROUND = pygame.transform.scale(pygame.image.load(os.path.join("Assets/background.jpg")), (WIDTH, HEIGHT))

# draw window and objects into game
def draw_window(purple, blue, purple_bullets, blue_bullets, purple_health, blue_health):
    WIN.fill(BLACK)
    WIN.blit(BACKGROUND, (0, 0))
    pygame.draw.rect(WIN, BLACK, LINE)

    purple_health_text = HEALTH_FONT.render("Purple Health: " + str(purple_health), 1, BLACK)
    blue_health_text = HEALTH_FONT.render("Blue Health: " + str(blue_health), 1, BLACK)
    WIN.blit(purple_health_text, (WIDTH - purple_health_text.get_width() - 10, 10))
    WIN.blit(blue_health_text, (10, 10))

    WIN.blit(blue_cat, (blue.x, blue.y))
    WIN.blit(pruple_cat, (purple.x, purple.y))

    for bullet in purple_bullets:
        pygame.draw.rect(WIN, PURPLE, bullet)

    for bullet in blue_bullets:
        pygame.draw.rect(WIN, BLUE, bullet)

    pygame.display.update()

# movement for blue cat
def blue_handle_movement(keys_pressed, blue):
        if keys_pressed[pygame.K_j] and blue.x - VEL > 0: # This is left
            blue.x -= VEL

        if keys_pressed[pygame.K_l] and blue.x + VEL + blue.width < WIDTH: # This is Right
            blue.x += VEL

        if keys_pressed[pygame.K_i] and blue.y - VEL > 0: # This is Up
            blue.y -= VEL

        if keys_pressed[pygame.K_k] and blue.y + VEL + blue.height < LINE.y: # This is Down
            blue.y += VEL

# movement for purple cat
def purple_handle_movement(keys_pressed, purple):
        if keys_pressed[pygame.K_a] and purple.x - VEL > 0: # This is left
            purple.x -= VEL

        if keys_pressed[pygame.K_d] and purple.x + VEL + purple.width < WIDTH: # This is Right
            purple.x += VEL

        if keys_pressed[pygame.K_w] and purple.y - VEL + purple.height > LINE.y + 76: # This is Up
            purple.y -= VEL

        if keys_pressed[pygame.K_s] and purple.y + VEL < 800 - 76: # This is Down
            purple.y += VEL

# direction of bullets and colliding
def handle_bullets(blue_bullets, purple_bullets, blue, purple):
    for bullet in blue_bullets:
        bullet.y += BULLET_VEL
        if purple.colliderect(bullet):
            pygame.event.post(pygame.event.Event(PURPLE_HIT))
            blue_bullets.remove(bullet)
        elif bullet.y > WIDTH:
            blue_bullets.remove(bullet)

    for bullet in purple_bullets:
        bullet.y -= BULLET_VEL
        if blue.colliderect(bullet):
            pygame.event.post(pygame.event.Event(BLUE_HIT))
            purple_bullets.remove(bullet)
        elif bullet.y < 0:
            purple_bullets.remove(bullet)

# text for winner
def draw_winner(text):
    draw_text = WINNER_FONT.render(text, 1, BLACK)
    WIN.blit(draw_text, (WIDTH/2 - draw_text.get_width() /2, HEIGHT/2 - draw_text.get_height()/2))
    pygame.display.update()
    pygame.time.delay(5000)


def main():
    blue = pygame.Rect(574, 200, 52, 72)
    purple = pygame.Rect(574, 600, 52, 72)

    purple_bullets = []
    blue_bullets = []

    purple_health = 10
    blue_health = 10

    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_u and len(blue_bullets) < MAX_BULLETS:
                    bullet = pygame.Rect(blue.x + blue.width, blue.y + blue.height//2 - 2, 5, 10)
                    blue_bullets.append(bullet)
                    BULLET_FIRE_SOUND.play()

                if event.key == pygame.K_e and len(purple_bullets) < MAX_BULLETS:
                    bullet = pygame.Rect(purple.x, purple.y + purple.height//2 - 2, 5, 10)
                    purple_bullets.append(bullet)
                    BULLET_FIRE_SOUND.play()

            if event.type == PURPLE_HIT:
                purple_health -= 1
                BULLET_HIT_SOUND.play()

            if event.type == BLUE_HIT:
                blue_health -= 1
                BULLET_HIT_SOUND.play()

        winner_text = ""
        if purple_health <= 0:
            winner_text = "THE BLUE CAT WINS"
            VICTORY_SOUND.play()

        if blue_health <= 0:
            winner_text = "THE PURPLE CAT WINS"
            VICTORY_SOUND.play()

        if winner_text != "":
            draw_winner(winner_text)
            break

        keys_pressed = pygame.key.get_pressed()
        blue_handle_movement(keys_pressed, blue)
        purple_handle_movement(keys_pressed, purple)

        handle_bullets(blue_bullets, purple_bullets, blue, purple)

        draw_window(purple, blue, purple_bullets, blue_bullets,
                    purple_health, blue_health)

    main()

def main_menu():
    clock = pygame.time.Clock()
    run = True
    while run:

        clock.tick(FPS)
        WIN.blit(BACKGROUND, (0, 0))

        MOUSE_POS = pygame.mouse.get_pos()

        MENU_FONT = WINNER_FONT.render("CATTACLE", True, WHITE)
        MENU_RECT = MENU_FONT.get_rect(center=(600, 100))

        PLAY_SCALE = pygame.transform.scale(pygame.image.load("Assets/start.jpg"), (300, 150))
        EXIT_SCALE = pygame.transform.scale(pygame.image.load("Assets/exit.jpg"), (300, 150))

        PLAY_BTTN = Button(image = PLAY_SCALE, pos = (600, 400), text_input="PLAY", font = BUTTON_FONT, base_color = WHITE, hovering_color = WHITE) 
        EXIT_BTTN = Button(image = EXIT_SCALE, pos = (600, 700), text_input="EXIT", font = BUTTON_FONT, base_color = WHITE, hovering_color = WHITE)

        WIN.blit(MENU_FONT, MENU_RECT)

        for button in [PLAY_BTTN, EXIT_BTTN]:
            button.changeColor(MOUSE_POS)
            button.update(WIN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BTTN.checkForInput(MOUSE_POS):
                    main()
                if EXIT_BTTN.checkForInput(MOUSE_POS):
                    run = False
                    pygame.quit()

        pygame.display.update()


if __name__ == "__main__":
    main_menu()
